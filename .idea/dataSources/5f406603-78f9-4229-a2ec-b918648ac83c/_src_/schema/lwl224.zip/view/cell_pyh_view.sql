CREATE VIEW cell_pyh_view AS
  SELECT
    `c`.`cellid1`             AS `cellid1`,
    `c`.`cellomcname`         AS `cellomcname`,
    `c`.`lon`                 AS `cell_lon`,
    `c`.`lat`                 AS `cell_lat`,
    `p`.`physicalstationid`   AS `physicalstationid`,
    `p`.`physicalstationname` AS `physicalstationname`,
    `p`.`lon`                 AS `pyh_lon`,
    `p`.`lat`                 AS `pyh_lat`,
    `c`.`customize9`          AS `customize9`
  FROM ((`lwl224`.`books_ltecell` `c` LEFT JOIN `lwl224`.`books_rru` `r` ON ((`c`.`cellid1` = `r`.`cellid1`))) LEFT JOIN
    `lwl224`.`books_physicalstation` `p` ON ((`r`.`physicalstationid` = `p`.`physicalstationid`)));
